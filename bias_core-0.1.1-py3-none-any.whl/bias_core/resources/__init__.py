# bias_core.resources
